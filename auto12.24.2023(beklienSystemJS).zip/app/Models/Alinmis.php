<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Alinmis extends Model
{
    use HasFactory;
    protected $table = 'alinmis';
    protected $guarded = ['id'];

}
