<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.navbars.auth.topnav', ['title' => 'Tables'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card mb-4">
                    <div class="card-header pb-0">
                        <h6>Odeme table</h6>
                    </div>
                    <div class="card-body px-0 pt-0 pb-2">
                        <div class="table-responsive p-0">
                            <table class="table align-items-center mb-0">
                                <thead>
                                    <tr>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                            #</th>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                            Tip</th>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                            Odeyen</th>
                                        <th
                                            class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                            Vade tarihi</th>
                                        <th
                                            class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                            Sekli</th>
                                        <th
                                            class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                            user</th>
                                        <th
                                            class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                            Aciklama</th>









                                        <th
                                            class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                            Tarih</th>
                                        <th
                                            class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                            Onay</th>

                                    </tr>
                                </thead>
                                <tbody>






























<style>
    .btnkia{
        margin: auto !important;
        padding: revert !important;
    }
</style>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>

                                            <p class="text-xm font-weight-lighter mb-0 px-2"><?php echo e($loop->iteration); ?></p>

                                        </td>
                                        <td>

                                            <p class="text-xm font-weight-lighter mb-0 px-2"><?php echo e($z->OdemeTipi); ?></p>

                                        </td>
                                        <td>











                                            <p class="text-xm font-weight-bold mb-0 px-2"><?php echo e($z->OdeyenAd); ?></p>
                                            <p class="text-xs text-secondary mb-0"><?php echo e($z->OdeyenSoyad); ?></p>

                                        </td>
                                        <td>



                                            <p class="text-xs font-weight-bold mb-0 "><?php echo e($z->VadeTarihi); ?></p>

                                        </td>





                                        <td class="align-middle text-center">
                                            <span class="text-secondary text-xs font-weight-bold"><?php echo e($z->OdemeSekli); ?></span>
                                        </td>



                                        <td class="align-middle text-center">
                                            <span class="text-secondary text-xs font-weight-bold"><?php echo e($z->kim); ?></span>
                                        </td>
                                        <td class="align-middle">






                                            <span class="text-secondary text-xs font-weight-bold"><?php echo e($z->OdemeAciklama); ?></span>
                                        </td>
                                        <td class="align-middle">
                                            <span class="text-secondary text-xs font-weight-bold"><?php echo e($z->created_at->todatestring()); ?></span>
                                        </td>
                                        <td class="align-middle">

                                                <span class="text-secondary text-xs font-weight-bold ">Onaylanmiş</span>
                                                <a href="<?php echo e(route('onay.durumu.change' , ['id' => $z->id])); ?>"><button type="button" class="btn btn-danger btn-sm btnkia"><i class="fa fa-trash"> iptal</i></button></a>




                                        </td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td>sililanlar</td>
</tr>
                                <?php $__currentLoopData = $sililanlar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>

                                            <p class="text-xm font-weight-lighter mb-0 px-2"><?php echo e($loop->iteration); ?></p>

                                        </td>
                                        <td>

                                            <p class="text-xm font-weight-lighter mb-0 px-2"><?php echo e($x->OdemeTipi); ?></p>

                                        </td>
                                        <td>

                                            <p class="text-xm font-weight-bold mb-0 px-2"><?php echo e($x->OdeyenAd); ?></p>
                                            <p class="text-xs text-secondary mb-0"><?php echo e($x->OdeyenSoyad); ?></p>

                                        </td>
                                        <td>
                                            <p class="text-xs font-weight-bold mb-0 "><?php echo e($x->VadeTarihi); ?></p>

                                        </td>
                                        <td class="align-middle text-center">
                                            <span class="text-secondary text-xs font-weight-bold"><?php echo e($x->OdemeSekli); ?></span>
                                        </td>
                                        <td class="align-middle text-center">
                                            <span class="text-secondary text-xs font-weight-bold"><?php echo e($x->kim); ?></span>
                                        </td>
                                        <td class="align-middle">
                                            <span class="text-secondary text-xs font-weight-bold"><?php echo e($z->OdemeAciklama); ?></span>
                                        </td>
                                        <td class="align-middle">
                                            <span class="text-secondary text-xs font-weight-bold"><?php echo e($z->created_at->todatestring()); ?></span>
                                        </td>
                                        <td class="align-middle">
                                                <span class="text-secondary text-xs font-weight-bold ">Silinmiş</span>





                                        </td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                </tbody>
                            </table>
                            <style>
                                td{
                                    white-space: normal !important;
                                }
                                table{table-layout: fixed;
                                    text-align: center;
                                }
                            </style>
                        </div>
                    </div>
                </div>
            </div>
        </div>






























































































































































































































































        <?php echo $__env->make('layouts.footers.auth.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\me\dukan projects\auto\resources\views/pages/user-odeme-index.blade.php ENDPATH**/ ?>