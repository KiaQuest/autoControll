<aside class="sidenav bg-white navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-4 "
    id="sidenav-main">










    <div class="collapse navbar-collapse  w-auto " id="sidenav-collapse-main" style="height: initial">
        <ul class="navbar-nav">




































                <style>
                    .collapsible {
                        background-color: #777;
                        color: white;
                        cursor: pointer;
                        padding: 18px;
                        width: 100%;
                        border: none;
                        text-align: left;
                        outline: none;
                        font-size: 15px;
                    }

                    .active, .collapsible:hover {
                        background-color: #555;
                    }

                    .content {
                        /*padding: 0 18px;*/
                        max-height: 0;
                        overflow: hidden;
                        transition: max-height 0.2s ease-out;
                        background-color: #f1f1f1;
                    }

                    .arrow {
                        border: solid black;
                        border-width: 0 3px 3px 0;
                        display: inline-block;
                        padding: 3px;
                    }.down {
                         transform: rotate(45deg);
                         -webkit-transform: rotate(45deg);
                     }

                     .po{
                         display: flex;
                         justify-content: space-between;
                         align-items: center;
                     }

                    li{
                        margin: 2px 0;
                    }
                </style>


            <style>
                .active, .collapsible:hover {
                    background-color: #d5d5d5 !important;
                }
            </style>
                <button class="collapsible po <?php echo e(Route::currentRouteName() == 'firma.show' ||  Route::currentRouteName() ==  'firma.index' ? 'active' : ''); ?>">Firma İşlemleri <i class="arrow down"></i></button>
                <div class="content" <?php echo e(Route::currentRouteName() == 'firma.show' ||  Route::currentRouteName() == 'firma.index' ? 'style=max-height:114px' : ''); ?>>

                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::currentRouteName() == 'firma.show' ? 'active' : ''); ?>" href="<?php echo e(route('firma.show')); ?>">
                            <div
                                class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="ni ni-single-02 text-dark text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">fırma ekle</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::currentRouteName() == 'firma.index' ? 'active' : ''); ?>" href="<?php echo e(route('firma.index')); ?>">
                            <div
                                class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="ni ni-single-02 text-dark text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">fırma listesı</span>
                        </a>
                    </li>


                </div>




                <button class="collapsible po  <?php echo e(Route::currentRouteName() == 'profile.ek' ||  Route::currentRouteName() == 'user'  ||  Route::currentRouteName() == 'is.show'  ||  Route::currentRouteName() == 'is.index'  ||  Route::currentRouteName() == 'ihtiac.show'  ||  Route::currentRouteName() == 'ihtiac.index'  ||  Route::currentRouteName() == 'sikayet.show'  ||  Route::currentRouteName() == 'sikayet.index' ? 'active' : ''); ?>">Çalışan İşlemleri <i class="arrow down"></i></button>
                <div class="content"  <?php echo e(Route::currentRouteName() == 'profile.ek' ||  Route::currentRouteName() == 'user' ||  Route::currentRouteName() == 'is.show'  ||  Route::currentRouteName() == 'is.index'  ||  Route::currentRouteName() == 'ihtiac.show'  ||  Route::currentRouteName() == 'ihtiac.index'  ||  Route::currentRouteName() == 'sikayet.show'  ||  Route::currentRouteName() == 'sikayet.index'  ? 'style=max-height:447px' : ''); ?>>

                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::currentRouteName() == 'profile.ek' ? 'active' : ''); ?>" href="<?php echo e(route('profile.ek')); ?>">
                            <div
                                class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="ni ni-single-02 text-dark text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Çalışn ekle</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::currentRouteName() == 'users' ? 'active' : ''); ?>" href="<?php echo e(route('users')); ?>">
                            <div
                                class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="ni ni-single-02 text-dark text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Çalışanlar</span>
                        </a>
                    </li>



                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::currentRouteName() == 'is.show' ? 'active' : ''); ?>" href="<?php echo e(route('is.show')); ?>">
                            <div
                                class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="ni ni-single-02 text-dark text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Iş Ekle</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::currentRouteName() == 'is.index' ? 'active' : ''); ?>" href="<?php echo e(route('is.index')); ?>">
                            <div
                                class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="ni ni-single-02 text-dark text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Yapılan işler</span>
                        </a>
                    </li>


                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::currentRouteName() == 'ihtiac.show' ? 'active' : ''); ?>" href="<?php echo e(route('ihtiac.show')); ?>">
                            <div
                                class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="ni ni-single-02 text-dark text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Ihtiac Ekle</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::currentRouteName() == 'ihtiac.index' ? 'active' : ''); ?>" href="<?php echo e(route('ihtiac.index')); ?>">
                            <div
                                class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="ni ni-single-02 text-dark text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">İhtiyaçlarım</span>
                        </a>
                    </li>


                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::currentRouteName() == 'sikayet.show' ? 'active' : ''); ?>" href="<?php echo e(route('sikayet.show')); ?>">
                            <div
                                class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="ni ni-single-02 text-dark text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Şikayet Ekle</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::currentRouteName() == 'sikayet.index' ? 'active' : ''); ?>" href="<?php echo e(route('sikayet.index')); ?>">
                            <div
                                class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="ni ni-single-02 text-dark text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Şikayetlerim</span>
                        </a>
                    </li>



                </div>



























                <button class="collapsible po  <?php echo e(Route::currentRouteName() == 'tarla.show' ||  Route::currentRouteName() == 'tarla.index' ||  Route::currentRouteName() == 'tarla.satis' ? 'active' : ''); ?>">Tarla İşlemleri <i class="arrow down"></i></button>
                <div class="content"  <?php echo e(Route::currentRouteName() == 'tarla.show' ||  Route::currentRouteName() == 'tarla.index' ||  Route::currentRouteName() == 'tarla.satis'  ? 'style=max-height:447px' : ''); ?>>
                    

                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::currentRouteName() == 'tarla.show' ? 'active' : ''); ?>" href="<?php echo e(route('tarla.show')); ?>">
                            <div
                                class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="ni ni-single-02 text-dark text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Tarla ekle</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::currentRouteName() == 'tarla.index' ? 'active' : ''); ?>" href="<?php echo e(route('tarla.index')); ?>">
                            <div
                                class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="ni ni-single-02 text-dark text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Tarla listesı</span>
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::currentRouteName() == 'tarla.satis' ? 'active' : ''); ?>" href="<?php echo e(route('tarla.satis')); ?>">
                            <div
                                class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="ni ni-single-02 text-dark text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Tarla Satışı</span>
                        </a>
                    </li>


                </div>


                <button class="collapsible po   <?php echo e(Route::currentRouteName() == 'odeme.show' ||  Route::currentRouteName() == 'odeme.index'  ||  Route::currentRouteName() == 'odeme.index.bekleyen'  ? 'active' : ''); ?>">Ödeme İşlemleri <i class="arrow down"></i></button>
                <div class="content"   <?php echo e(Route::currentRouteName() == 'odeme.show' ||  Route::currentRouteName() == 'odeme.index'  ||  Route::currentRouteName() == 'odeme.index.bekleyen'  ? 'style=max-height:447px' : ''); ?>>



                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::currentRouteName() == 'odeme.show' ? 'active' : ''); ?>" href="<?php echo e(route('odeme.show')); ?>">
                            <div
                                class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="ni ni-single-02 text-dark text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Ödeme Ekle <br> <span class="text-xxs font-weight-lighter mb-0 px-2" style="font-weight: 100 !important;">( alacak & verecek )</span></span>
                        </a>
                    </li>



                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::currentRouteName() == 'odeme.index' ? 'active' : ''); ?>" href="<?php echo e(route('odeme.index')); ?>">
                            <div
                                class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="ni ni-single-02 text-dark text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Ödeme listesı</span>

                        </a>
                    </li>


























                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::currentRouteName() == 'odeme.index.bekleyen' ? 'active' : ''); ?>" href="<?php echo e(route('odeme.index.bekleyen')); ?>">
                            <div
                                class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="ni ni-single-02 text-dark text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Onay bekleyen</span>
                        </a>
                    </li>


                </div>



                <button class="collapsible po">Müşteri İşlemleri <i class="arrow down"></i></button>
                <div class="content">
                    

                </div>


                <button class="collapsible po">Çalışan Kontrol <i class="arrow down"></i></button>
                <div class="content">


                </div>



                <button class="collapsible po">Yönetici İşlemleri <i class="arrow down"></i></button>
                <div class="content">
                    

                </div>


                <button class="collapsible po">Müdür Kontrol <i class="arrow down"></i></button>
                <div class="content">
                    


                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::currentRouteName() == 'users' ? 'active' : ''); ?>" href="<?php echo e(route('users')); ?>">

                            <div
                                class="icon icon-shape icon-sm border-radius-md text-center me-2 d-flex align-items-center justify-content-center">
                                <i class="ni ni-single-02 text-dark text-sm opacity-10"></i>
                            </div>
                            <span class="nav-link-text ms-1">Çalışanlarim</span>
                        </a>
                    </li>


                </div>


                <script>
                    var coll = document.getElementsByClassName("collapsible");
                    var i;

                    for (i = 0; i < coll.length; i++) {
                        coll[i].addEventListener("click", function() {
                            this.classList.toggle("active");
                            var content = this.nextElementSibling;
                            if (content.style.maxHeight){
                                content.style.maxHeight = null;
                            } else {
                                content.style.maxHeight = content.scrollHeight + "px";
                            }
                        });
                    }
                </script>




















































































        </ul>
    </div>
















</aside>
<?php /**PATH C:\xampp\htdocs\me\dukan projects\auto\resources\views/layouts/navbars/auth/sidenav.blade.php ENDPATH**/ ?>