<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.navbars.auth.topnav', ['title' => 'Tables'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card mb-4">
                    <div class="card-header pb-0">
                        <h6>Authors table</h6>
                    </div>
                    <div class="card-body px-0 pt-0 pb-2">
                        <div class="table-responsive p-0">
                            <table class="table align-items-center mb-0">
                                <thead>
                                    <tr>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                            #</th>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                            Il</th>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">
                                            Ilce</th>
                                        <th
                                            class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                            Durum</th>
                                        <th
                                            class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                            Ada</th>
                                        <th
                                            class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                            Parsel</th>
                                        <th
                                            class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                            Parsel Sayi</th>
                                        <th
                                            class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                            Metrekare</th>
                                        <th
                                            class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                            Sahip</th>
                                        <th
                                            class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                            Tarih</th>
                                        <th
                                            class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">
                                            islem</th>
                                        <th class="text-secondary opacity-7"></th>
                                    </tr>
                                </thead>
                                <tbody>
































                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>

                                            <p class="text-xm font-weight-lighter mb-0 px-2"><?php echo e($loop->iteration); ?></p>

                                        </td>
                                        <td>











                                            <p class="text-xm font-weight-bold mb-0 px-2"><?php echo e($z->konum_il); ?></p>

                                        </td>
                                        <td>



                                            <p class="text-xs font-weight-bold mb-0 "><?php echo e($z->konum_ilce); ?></p>

                                        </td>
                                        <td class="align-middle text-center text-sm">
                                            <a href="<?php echo e(route('satisDurumu.change' , [ 'id' => $z->id , 'durum' => $z->SatisDurumu])); ?>"><span class="badge badge-sm bg-gradient-<?php echo e($z->SatisDurumu == 0 ? "secondary" : "success"); ?>"><?php echo e($z->SatisDurumu == 0 ? "Satışta Değil" : "Satışta"); ?></span></a>

                                        </td>
                                        <td class="align-middle text-center">
                                            <span class="text-secondary text-xs font-weight-bold"><?php echo e($z->Ada); ?></span>
                                        </td>
                                        <td class="align-middle text-center">
                                            <span class="text-secondary text-xs font-weight-bold"><?php echo e($z->Parsel); ?></span>
                                        </td>
                                        <td class="align-middle text-center">
                                            <span class="text-secondary text-xs font-weight-bold"><?php echo e($z->ParselSayisi); ?></span>
                                        </td>
                                        <td class="align-middle text-center">
                                            <span class="text-secondary text-xs font-weight-bold"><?php echo e($z->MetreKare); ?></span>
                                        </td>
                                        <td class="align-middle">




                                            <p class="text-xs font-weight-bold mb-0"><?php echo e($z->SahipAd); ?></p>
                                            <p class="text-xs text-secondary mb-0"><?php echo e($z->SahipSoyad); ?></p>
                                        </td>
                                        <td class="align-middle">
                                            <span class="text-secondary text-xs font-weight-bold"><?php echo e($z->created_at->toDateString()); ?></span>
                                        </td>
                                        <td class="align-middle">
                                            <a href="<?php echo e(route('tarla.edit' , ['id' => $z->id])); ?>"><span class="badge badge-sm bg-gradient-info">Düzenle</span></a>
                                        </td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <style>
                                td{
                                    white-space: normal !important
                                }
                                table{table-layout: fixed;
                                    text-align: center;
                                }
                            </style>
                        </div>
                    </div>
                </div>
            </div>
        </div>






























































































































































































































































        <?php echo $__env->make('layouts.footers.auth.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['class' => 'g-sidenav-show bg-gray-100'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\me\dukan projects\auto\resources\views/pages/user-tarla-index.blade.php ENDPATH**/ ?>